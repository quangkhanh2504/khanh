﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL
{
    public  class DBConnect
    {
        protected SqlConnection cnn = new SqlConnection("Data Source=LAPTOP-HRKD5F7M\\SQLEXPRESS;Initial Catalog=CGV;Integrated Security=True;Encrypt=False;");
    }
}
