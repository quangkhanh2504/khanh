﻿namespace UI
{
    partial class frmStaff
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmStaff));
            this.dgvDSPhim = new System.Windows.Forms.DataGridView();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnXoa = new System.Windows.Forms.Button();
            this.btnChon = new System.Windows.Forms.Button();
            this.pbPoster = new System.Windows.Forms.PictureBox();
            this.lblPhim = new System.Windows.Forms.Label();
            this.cbPhim = new System.Windows.Forms.ComboBox();
            this.lblThoiGian = new System.Windows.Forms.Label();
            this.dtpThoiGian = new System.Windows.Forms.DateTimePicker();
            this.txtNgayCongChieu = new System.Windows.Forms.TextBox();
            this.lblNgayCongChieu = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.lblGioiHanDoTuoi = new System.Windows.Forms.Label();
            this.txtGioiHanDoTuoi = new System.Windows.Forms.TextBox();
            this.txtNSX = new System.Windows.Forms.TextBox();
            this.lblNSX = new System.Windows.Forms.Label();
            this.txtTheLoai = new System.Windows.Forms.TextBox();
            this.lblTheLoai = new System.Windows.Forms.Label();
            this.txtDaoDien = new System.Windows.Forms.TextBox();
            this.lblDaoDien = new System.Windows.Forms.Label();
            this.txtTenPhim = new System.Windows.Forms.TextBox();
            this.lblTenPhim = new System.Windows.Forms.Label();
            this.txtMaPhim = new System.Windows.Forms.TextBox();
            this.lblMaPhim = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.btnChonGhe = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.btnQuayLai = new System.Windows.Forms.Button();
            this.lblLCP = new System.Windows.Forms.Label();
            this.btnClose = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDSPhim)).BeginInit();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbPoster)).BeginInit();
            this.panel3.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // dgvDSPhim
            // 
            this.dgvDSPhim.BackgroundColor = System.Drawing.Color.MintCream;
            this.dgvDSPhim.BorderStyle = System.Windows.Forms.BorderStyle.None;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.MistyRose;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvDSPhim.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.dgvDSPhim.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.Color.MistyRose;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvDSPhim.DefaultCellStyle = dataGridViewCellStyle4;
            this.dgvDSPhim.GridColor = System.Drawing.Color.MistyRose;
            this.dgvDSPhim.Location = new System.Drawing.Point(333, 117);
            this.dgvDSPhim.Name = "dgvDSPhim";
            this.dgvDSPhim.RowHeadersWidth = 51;
            this.dgvDSPhim.RowTemplate.Height = 24;
            this.dgvDSPhim.Size = new System.Drawing.Size(760, 266);
            this.dgvDSPhim.TabIndex = 17;
            this.dgvDSPhim.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvDSPhim_CellClick);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.MintCream;
            this.panel1.Controls.Add(this.btnXoa);
            this.panel1.Controls.Add(this.btnChon);
            this.panel1.Controls.Add(this.pbPoster);
            this.panel1.Controls.Add(this.lblPhim);
            this.panel1.Controls.Add(this.cbPhim);
            this.panel1.Controls.Add(this.lblThoiGian);
            this.panel1.Controls.Add(this.dtpThoiGian);
            this.panel1.Location = new System.Drawing.Point(13, 117);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(306, 522);
            this.panel1.TabIndex = 15;
            // 
            // btnXoa
            // 
            this.btnXoa.BackColor = System.Drawing.Color.Maroon;
            this.btnXoa.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnXoa.ForeColor = System.Drawing.Color.White;
            this.btnXoa.Location = new System.Drawing.Point(160, 471);
            this.btnXoa.Name = "btnXoa";
            this.btnXoa.Size = new System.Drawing.Size(121, 38);
            this.btnXoa.TabIndex = 9;
            this.btnXoa.Text = "XÓA";
            this.btnXoa.UseVisualStyleBackColor = false;
            this.btnXoa.Click += new System.EventHandler(this.btnXoa_Click);
            // 
            // btnChon
            // 
            this.btnChon.BackColor = System.Drawing.Color.Maroon;
            this.btnChon.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnChon.ForeColor = System.Drawing.Color.White;
            this.btnChon.Location = new System.Drawing.Point(15, 471);
            this.btnChon.Name = "btnChon";
            this.btnChon.Size = new System.Drawing.Size(121, 38);
            this.btnChon.TabIndex = 8;
            this.btnChon.Text = "CHỌN";
            this.btnChon.UseVisualStyleBackColor = false;
            this.btnChon.Click += new System.EventHandler(this.btnChon_Click);
            // 
            // pbPoster
            // 
            this.pbPoster.BackColor = System.Drawing.Color.MistyRose;
            this.pbPoster.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pbPoster.Image = ((System.Drawing.Image)(resources.GetObject("pbPoster.Image")));
            this.pbPoster.Location = new System.Drawing.Point(32, 154);
            this.pbPoster.Name = "pbPoster";
            this.pbPoster.Size = new System.Drawing.Size(231, 307);
            this.pbPoster.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbPoster.TabIndex = 7;
            this.pbPoster.TabStop = false;
            // 
            // lblPhim
            // 
            this.lblPhim.AutoSize = true;
            this.lblPhim.BackColor = System.Drawing.Color.MintCream;
            this.lblPhim.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPhim.Location = new System.Drawing.Point(10, 87);
            this.lblPhim.Name = "lblPhim";
            this.lblPhim.Size = new System.Drawing.Size(85, 25);
            this.lblPhim.TabIndex = 6;
            this.lblPhim.Text = "PHIM:";
            // 
            // cbPhim
            // 
            this.cbPhim.Font = new System.Drawing.Font("Times New Roman", 10.8F);
            this.cbPhim.FormattingEnabled = true;
            this.cbPhim.Items.AddRange(new object[] {
            "Trạng Tí Phiêu Lưu Ký",
            "Nhà Không Bán",
            "Encanto - Vùng Đất Thần Kỳ",
            "Sing 2 - Đấu Trường Âm Nhạc 2",
            "Moonfall",
            "Mưu Kế Thượng Lưu",
            "Chuyện Ma Gần Nhà",
            "Bẫy Ngọt Ngào",
            "Chuyện Xứ Lang Biang"});
            this.cbPhim.Location = new System.Drawing.Point(15, 115);
            this.cbPhim.Name = "cbPhim";
            this.cbPhim.Size = new System.Drawing.Size(266, 28);
            this.cbPhim.TabIndex = 5;
            // 
            // lblThoiGian
            // 
            this.lblThoiGian.AutoSize = true;
            this.lblThoiGian.BackColor = System.Drawing.Color.MintCream;
            this.lblThoiGian.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblThoiGian.Location = new System.Drawing.Point(10, 13);
            this.lblThoiGian.Name = "lblThoiGian";
            this.lblThoiGian.Size = new System.Drawing.Size(146, 25);
            this.lblThoiGian.TabIndex = 1;
            this.lblThoiGian.Text = "THỜI GIAN:";
            // 
            // dtpThoiGian
            // 
            this.dtpThoiGian.CalendarTitleBackColor = System.Drawing.Color.Maroon;
            this.dtpThoiGian.CustomFormat = "dd/MM/yyyy";
            this.dtpThoiGian.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpThoiGian.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpThoiGian.Location = new System.Drawing.Point(15, 41);
            this.dtpThoiGian.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.dtpThoiGian.MaxDate = new System.DateTime(2024, 12, 31, 0, 0, 0, 0);
            this.dtpThoiGian.MinDate = new System.DateTime(2020, 1, 1, 0, 0, 0, 0);
            this.dtpThoiGian.Name = "dtpThoiGian";
            this.dtpThoiGian.Size = new System.Drawing.Size(266, 28);
            this.dtpThoiGian.TabIndex = 4;
            this.dtpThoiGian.Value = new System.DateTime(2022, 10, 31, 0, 0, 0, 0);
            // 
            // txtNgayCongChieu
            // 
            this.txtNgayCongChieu.Font = new System.Drawing.Font("Times New Roman", 12F);
            this.txtNgayCongChieu.Location = new System.Drawing.Point(190, 143);
            this.txtNgayCongChieu.Name = "txtNgayCongChieu";
            this.txtNgayCongChieu.Size = new System.Drawing.Size(255, 30);
            this.txtNgayCongChieu.TabIndex = 24;
            // 
            // lblNgayCongChieu
            // 
            this.lblNgayCongChieu.AutoSize = true;
            this.lblNgayCongChieu.BackColor = System.Drawing.Color.MintCream;
            this.lblNgayCongChieu.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNgayCongChieu.Location = new System.Drawing.Point(20, 151);
            this.lblNgayCongChieu.Name = "lblNgayCongChieu";
            this.lblNgayCongChieu.Size = new System.Drawing.Size(154, 22);
            this.lblNgayCongChieu.TabIndex = 23;
            this.lblNgayCongChieu.Text = "Ngày Công Chiếu:";
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.MintCream;
            this.panel3.Controls.Add(this.txtNgayCongChieu);
            this.panel3.Controls.Add(this.lblNgayCongChieu);
            this.panel3.Controls.Add(this.lblGioiHanDoTuoi);
            this.panel3.Controls.Add(this.txtGioiHanDoTuoi);
            this.panel3.Controls.Add(this.txtNSX);
            this.panel3.Controls.Add(this.lblNSX);
            this.panel3.Controls.Add(this.txtTheLoai);
            this.panel3.Controls.Add(this.lblTheLoai);
            this.panel3.Controls.Add(this.txtDaoDien);
            this.panel3.Controls.Add(this.lblDaoDien);
            this.panel3.Controls.Add(this.txtTenPhim);
            this.panel3.Controls.Add(this.lblTenPhim);
            this.panel3.Controls.Add(this.txtMaPhim);
            this.panel3.Controls.Add(this.lblMaPhim);
            this.panel3.Controls.Add(this.label1);
            this.panel3.Controls.Add(this.btnChonGhe);
            this.panel3.Location = new System.Drawing.Point(333, 396);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(760, 242);
            this.panel3.TabIndex = 18;
            // 
            // lblGioiHanDoTuoi
            // 
            this.lblGioiHanDoTuoi.AutoSize = true;
            this.lblGioiHanDoTuoi.BackColor = System.Drawing.Color.MintCream;
            this.lblGioiHanDoTuoi.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblGioiHanDoTuoi.Location = new System.Drawing.Point(20, 195);
            this.lblGioiHanDoTuoi.Name = "lblGioiHanDoTuoi";
            this.lblGioiHanDoTuoi.Size = new System.Drawing.Size(160, 22);
            this.lblGioiHanDoTuoi.TabIndex = 22;
            this.lblGioiHanDoTuoi.Text = "Giới Hạn Độ Tuổi:";
            // 
            // txtGioiHanDoTuoi
            // 
            this.txtGioiHanDoTuoi.Font = new System.Drawing.Font("Times New Roman", 12F);
            this.txtGioiHanDoTuoi.Location = new System.Drawing.Point(190, 187);
            this.txtGioiHanDoTuoi.Name = "txtGioiHanDoTuoi";
            this.txtGioiHanDoTuoi.Size = new System.Drawing.Size(255, 30);
            this.txtGioiHanDoTuoi.TabIndex = 21;
            // 
            // txtNSX
            // 
            this.txtNSX.Font = new System.Drawing.Font("Times New Roman", 12F);
            this.txtNSX.Location = new System.Drawing.Point(574, 143);
            this.txtNSX.Name = "txtNSX";
            this.txtNSX.Size = new System.Drawing.Size(169, 30);
            this.txtNSX.TabIndex = 20;
            // 
            // lblNSX
            // 
            this.lblNSX.AutoSize = true;
            this.lblNSX.BackColor = System.Drawing.Color.MintCream;
            this.lblNSX.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNSX.Location = new System.Drawing.Point(513, 151);
            this.lblNSX.Name = "lblNSX";
            this.lblNSX.Size = new System.Drawing.Size(55, 22);
            this.lblNSX.TabIndex = 19;
            this.lblNSX.Text = "NSX:";
            // 
            // txtTheLoai
            // 
            this.txtTheLoai.Font = new System.Drawing.Font("Times New Roman", 12F);
            this.txtTheLoai.Location = new System.Drawing.Point(574, 101);
            this.txtTheLoai.Name = "txtTheLoai";
            this.txtTheLoai.Size = new System.Drawing.Size(169, 30);
            this.txtTheLoai.TabIndex = 18;
            // 
            // lblTheLoai
            // 
            this.lblTheLoai.AutoSize = true;
            this.lblTheLoai.BackColor = System.Drawing.Color.MintCream;
            this.lblTheLoai.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTheLoai.Location = new System.Drawing.Point(481, 109);
            this.lblTheLoai.Name = "lblTheLoai";
            this.lblTheLoai.Size = new System.Drawing.Size(87, 22);
            this.lblTheLoai.TabIndex = 17;
            this.lblTheLoai.Text = "Thể Loại:";
            // 
            // txtDaoDien
            // 
            this.txtDaoDien.Font = new System.Drawing.Font("Times New Roman", 12F);
            this.txtDaoDien.Location = new System.Drawing.Point(574, 58);
            this.txtDaoDien.Name = "txtDaoDien";
            this.txtDaoDien.Size = new System.Drawing.Size(168, 30);
            this.txtDaoDien.TabIndex = 16;
            // 
            // lblDaoDien
            // 
            this.lblDaoDien.AutoSize = true;
            this.lblDaoDien.BackColor = System.Drawing.Color.MintCream;
            this.lblDaoDien.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDaoDien.Location = new System.Drawing.Point(476, 66);
            this.lblDaoDien.Name = "lblDaoDien";
            this.lblDaoDien.Size = new System.Drawing.Size(92, 22);
            this.lblDaoDien.TabIndex = 15;
            this.lblDaoDien.Text = "Đạo Diễn:";
            // 
            // txtTenPhim
            // 
            this.txtTenPhim.Font = new System.Drawing.Font("Times New Roman", 12F);
            this.txtTenPhim.Location = new System.Drawing.Point(117, 101);
            this.txtTenPhim.Name = "txtTenPhim";
            this.txtTenPhim.Size = new System.Drawing.Size(328, 30);
            this.txtTenPhim.TabIndex = 14;
            // 
            // lblTenPhim
            // 
            this.lblTenPhim.AutoSize = true;
            this.lblTenPhim.BackColor = System.Drawing.Color.MintCream;
            this.lblTenPhim.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTenPhim.Location = new System.Drawing.Point(20, 109);
            this.lblTenPhim.Name = "lblTenPhim";
            this.lblTenPhim.Size = new System.Drawing.Size(91, 22);
            this.lblTenPhim.TabIndex = 13;
            this.lblTenPhim.Text = "Tên Phim:";
            // 
            // txtMaPhim
            // 
            this.txtMaPhim.Font = new System.Drawing.Font("Times New Roman", 12F);
            this.txtMaPhim.Location = new System.Drawing.Point(117, 58);
            this.txtMaPhim.Name = "txtMaPhim";
            this.txtMaPhim.Size = new System.Drawing.Size(328, 30);
            this.txtMaPhim.TabIndex = 12;
            // 
            // lblMaPhim
            // 
            this.lblMaPhim.AutoSize = true;
            this.lblMaPhim.BackColor = System.Drawing.Color.MintCream;
            this.lblMaPhim.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMaPhim.Location = new System.Drawing.Point(20, 66);
            this.lblMaPhim.Name = "lblMaPhim";
            this.lblMaPhim.Size = new System.Drawing.Size(87, 22);
            this.lblMaPhim.TabIndex = 11;
            this.lblMaPhim.Text = "Mã Phim:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.MintCream;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(10, 14);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(116, 25);
            this.label1.TabIndex = 10;
            this.label1.Text = "CHI TIẾT";
            // 
            // btnChonGhe
            // 
            this.btnChonGhe.BackColor = System.Drawing.Color.Maroon;
            this.btnChonGhe.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnChonGhe.ForeColor = System.Drawing.Color.White;
            this.btnChonGhe.Location = new System.Drawing.Point(517, 187);
            this.btnChonGhe.Name = "btnChonGhe";
            this.btnChonGhe.Size = new System.Drawing.Size(229, 38);
            this.btnChonGhe.TabIndex = 10;
            this.btnChonGhe.Text = "CHỌN GHẾ NGỒI >>>";
            this.btnChonGhe.UseVisualStyleBackColor = false;
            this.btnChonGhe.Click += new System.EventHandler(this.btnChonGhe_Click);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.MintCream;
            this.panel2.Controls.Add(this.btnClose);
            this.panel2.Controls.Add(this.btnQuayLai);
            this.panel2.Controls.Add(this.lblLCP);
            this.panel2.Location = new System.Drawing.Point(0, -1);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1110, 107);
            this.panel2.TabIndex = 16;
            // 
            // btnQuayLai
            // 
            this.btnQuayLai.BackColor = System.Drawing.Color.Maroon;
            this.btnQuayLai.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnQuayLai.ForeColor = System.Drawing.Color.White;
            this.btnQuayLai.Location = new System.Drawing.Point(13, 13);
            this.btnQuayLai.Name = "btnQuayLai";
            this.btnQuayLai.Size = new System.Drawing.Size(57, 38);
            this.btnQuayLai.TabIndex = 10;
            this.btnQuayLai.Text = "<";
            this.btnQuayLai.UseVisualStyleBackColor = false;
            this.btnQuayLai.Click += new System.EventHandler(this.btnQuayLai_Click);
            // 
            // lblLCP
            // 
            this.lblLCP.AutoSize = true;
            this.lblLCP.Font = new System.Drawing.Font("Times New Roman", 20.25F, System.Drawing.FontStyle.Bold);
            this.lblLCP.Location = new System.Drawing.Point(393, 35);
            this.lblLCP.Name = "lblLCP";
            this.lblLCP.Size = new System.Drawing.Size(326, 38);
            this.lblLCP.TabIndex = 0;
            this.lblLCP.Text = "LỊCH CHIẾU PHIM";
            // 
            // btnClose
            // 
            this.btnClose.BackColor = System.Drawing.Color.Maroon;
            this.btnClose.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold);
            this.btnClose.ForeColor = System.Drawing.Color.White;
            this.btnClose.Location = new System.Drawing.Point(1036, 12);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(57, 38);
            this.btnClose.TabIndex = 32;
            this.btnClose.Text = "x";
            this.btnClose.UseVisualStyleBackColor = false;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // frmStaff
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Maroon;
            this.ClientSize = new System.Drawing.Size(1105, 650);
            this.Controls.Add(this.dgvDSPhim);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "frmStaff";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "frmStaff";
            ((System.ComponentModel.ISupportInitialize)(this.dgvDSPhim)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbPoster)).EndInit();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView dgvDSPhim;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btnXoa;
        private System.Windows.Forms.Button btnChon;
        private System.Windows.Forms.PictureBox pbPoster;
        private System.Windows.Forms.Label lblPhim;
        private System.Windows.Forms.ComboBox cbPhim;
        private System.Windows.Forms.Label lblThoiGian;
        private System.Windows.Forms.DateTimePicker dtpThoiGian;
        private System.Windows.Forms.TextBox txtNgayCongChieu;
        private System.Windows.Forms.Label lblNgayCongChieu;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label lblGioiHanDoTuoi;
        private System.Windows.Forms.TextBox txtGioiHanDoTuoi;
        private System.Windows.Forms.TextBox txtNSX;
        private System.Windows.Forms.Label lblNSX;
        private System.Windows.Forms.TextBox txtTheLoai;
        private System.Windows.Forms.Label lblTheLoai;
        private System.Windows.Forms.TextBox txtDaoDien;
        private System.Windows.Forms.Label lblDaoDien;
        private System.Windows.Forms.TextBox txtTenPhim;
        private System.Windows.Forms.Label lblTenPhim;
        private System.Windows.Forms.TextBox txtMaPhim;
        private System.Windows.Forms.Label lblMaPhim;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnChonGhe;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button btnQuayLai;
        private System.Windows.Forms.Label lblLCP;
        private System.Windows.Forms.Button btnClose;
    }
}