﻿namespace UI
{
    partial class frmSeat
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblTongTien = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.txtPhongChieu = new System.Windows.Forms.TextBox();
            this.lblPhongChieu = new System.Windows.Forms.Label();
            this.lblTrangThaiGhe = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.btnGheDangChon = new System.Windows.Forms.Button();
            this.btnGheDaMua = new System.Windows.Forms.Button();
            this.flpSeat = new System.Windows.Forms.FlowLayoutPanel();
            this.checkBox4 = new System.Windows.Forms.CheckBox();
            this.checkBox3 = new System.Windows.Forms.CheckBox();
            this.checkBox2 = new System.Windows.Forms.CheckBox();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.txtSLTreEm = new System.Windows.Forms.TextBox();
            this.txtSLSinhVien = new System.Windows.Forms.TextBox();
            this.txtSLNguoiGia = new System.Windows.Forms.TextBox();
            this.lblLoaiVe = new System.Windows.Forms.Label();
            this.txtGhe = new System.Windows.Forms.TextBox();
            this.txtThoiGian = new System.Windows.Forms.TextBox();
            this.lblThanhToan = new System.Windows.Forms.Label();
            this.txtSLNguoiLon = new System.Windows.Forms.TextBox();
            this.lblChiTiet = new System.Windows.Forms.Label();
            this.btnHuy = new System.Windows.Forms.Button();
            this.btnClose = new System.Windows.Forms.Button();
            this.pnlThanhToan = new System.Windows.Forms.Panel();
            this.txtTongTien = new System.Windows.Forms.TextBox();
            this.btnThanhToan = new System.Windows.Forms.Button();
            this.btnQuayLai = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.lblLCP = new System.Windows.Forms.Label();
            this.pnlChiTiet = new System.Windows.Forms.Panel();
            this.panel4.SuspendLayout();
            this.pnlThanhToan.SuspendLayout();
            this.panel2.SuspendLayout();
            this.pnlChiTiet.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblTongTien
            // 
            this.lblTongTien.AutoSize = true;
            this.lblTongTien.BackColor = System.Drawing.Color.MintCream;
            this.lblTongTien.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTongTien.Location = new System.Drawing.Point(25, 93);
            this.lblTongTien.Name = "lblTongTien";
            this.lblTongTien.Size = new System.Drawing.Size(90, 22);
            this.lblTongTien.TabIndex = 11;
            this.lblTongTien.Text = "Tổng tiền:";
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.MintCream;
            this.panel4.Controls.Add(this.txtPhongChieu);
            this.panel4.Controls.Add(this.lblPhongChieu);
            this.panel4.Controls.Add(this.lblTrangThaiGhe);
            this.panel4.Controls.Add(this.label6);
            this.panel4.Controls.Add(this.label2);
            this.panel4.Controls.Add(this.btnGheDangChon);
            this.panel4.Controls.Add(this.btnGheDaMua);
            this.panel4.Location = new System.Drawing.Point(12, 61);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(279, 328);
            this.panel4.TabIndex = 30;
            // 
            // txtPhongChieu
            // 
            this.txtPhongChieu.BackColor = System.Drawing.Color.MintCream;
            this.txtPhongChieu.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtPhongChieu.Font = new System.Drawing.Font("Times New Roman", 12F);
            this.txtPhongChieu.Location = new System.Drawing.Point(24, 61);
            this.txtPhongChieu.Name = "txtPhongChieu";
            this.txtPhongChieu.Size = new System.Drawing.Size(212, 23);
            this.txtPhongChieu.TabIndex = 15;
            // 
            // lblPhongChieu
            // 
            this.lblPhongChieu.AutoSize = true;
            this.lblPhongChieu.BackColor = System.Drawing.Color.MintCream;
            this.lblPhongChieu.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPhongChieu.Location = new System.Drawing.Point(19, 23);
            this.lblPhongChieu.Name = "lblPhongChieu";
            this.lblPhongChieu.Size = new System.Drawing.Size(180, 25);
            this.lblPhongChieu.TabIndex = 15;
            this.lblPhongChieu.Text = "PHÒNG CHIẾU";
            // 
            // lblTrangThaiGhe
            // 
            this.lblTrangThaiGhe.AutoSize = true;
            this.lblTrangThaiGhe.BackColor = System.Drawing.Color.MintCream;
            this.lblTrangThaiGhe.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTrangThaiGhe.Location = new System.Drawing.Point(19, 103);
            this.lblTrangThaiGhe.Name = "lblTrangThaiGhe";
            this.lblTrangThaiGhe.Size = new System.Drawing.Size(217, 25);
            this.lblTrangThaiGhe.TabIndex = 15;
            this.lblTrangThaiGhe.Text = "TRẠNG THÁI GHẾ";
            this.lblTrangThaiGhe.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.MintCream;
            this.label6.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(93, 206);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(126, 22);
            this.label6.TabIndex = 16;
            this.label6.Text = "Ghế đang chọn";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.MintCream;
            this.label2.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(93, 151);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(103, 22);
            this.label2.TabIndex = 15;
            this.label2.Text = "Ghế đã mua";
            // 
            // btnGheDangChon
            // 
            this.btnGheDangChon.BackColor = System.Drawing.Color.Salmon;
            this.btnGheDangChon.Location = new System.Drawing.Point(36, 200);
            this.btnGheDangChon.Name = "btnGheDangChon";
            this.btnGheDangChon.Size = new System.Drawing.Size(32, 33);
            this.btnGheDangChon.TabIndex = 1;
            this.btnGheDangChon.UseVisualStyleBackColor = false;
            // 
            // btnGheDaMua
            // 
            this.btnGheDaMua.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnGheDaMua.Location = new System.Drawing.Point(36, 145);
            this.btnGheDaMua.Name = "btnGheDaMua";
            this.btnGheDaMua.Size = new System.Drawing.Size(32, 33);
            this.btnGheDaMua.TabIndex = 0;
            this.btnGheDaMua.UseVisualStyleBackColor = false;
            // 
            // flpSeat
            // 
            this.flpSeat.AutoScroll = true;
            this.flpSeat.BackColor = System.Drawing.Color.MintCream;
            this.flpSeat.FlowDirection = System.Windows.Forms.FlowDirection.RightToLeft;
            this.flpSeat.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.flpSeat.Location = new System.Drawing.Point(303, 123);
            this.flpSeat.Name = "flpSeat";
            this.flpSeat.Size = new System.Drawing.Size(790, 266);
            this.flpSeat.TabIndex = 32;
            // 
            // checkBox4
            // 
            this.checkBox4.AutoSize = true;
            this.checkBox4.Font = new System.Drawing.Font("Times New Roman", 12F);
            this.checkBox4.Location = new System.Drawing.Point(370, 97);
            this.checkBox4.Name = "checkBox4";
            this.checkBox4.Size = new System.Drawing.Size(106, 26);
            this.checkBox4.TabIndex = 30;
            this.checkBox4.Text = "Sinh viên";
            this.checkBox4.UseVisualStyleBackColor = true;
            // 
            // checkBox3
            // 
            this.checkBox3.AutoSize = true;
            this.checkBox3.Font = new System.Drawing.Font("Times New Roman", 12F);
            this.checkBox3.Location = new System.Drawing.Point(370, 56);
            this.checkBox3.Name = "checkBox3";
            this.checkBox3.Size = new System.Drawing.Size(87, 26);
            this.checkBox3.TabIndex = 29;
            this.checkBox3.Text = "Trẻ em";
            this.checkBox3.UseVisualStyleBackColor = true;
            // 
            // checkBox2
            // 
            this.checkBox2.AutoSize = true;
            this.checkBox2.Font = new System.Drawing.Font("Times New Roman", 12F);
            this.checkBox2.Location = new System.Drawing.Point(107, 98);
            this.checkBox2.Name = "checkBox2";
            this.checkBox2.Size = new System.Drawing.Size(112, 26);
            this.checkBox2.TabIndex = 28;
            this.checkBox2.Text = "Người già";
            this.checkBox2.UseVisualStyleBackColor = true;
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Font = new System.Drawing.Font("Times New Roman", 12F);
            this.checkBox1.Location = new System.Drawing.Point(108, 55);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(114, 26);
            this.checkBox1.TabIndex = 27;
            this.checkBox1.Text = "Người lớn";
            this.checkBox1.UseVisualStyleBackColor = true;
            // 
            // txtSLTreEm
            // 
            this.txtSLTreEm.BackColor = System.Drawing.Color.MintCream;
            this.txtSLTreEm.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtSLTreEm.Font = new System.Drawing.Font("Times New Roman", 12F);
            this.txtSLTreEm.Location = new System.Drawing.Point(483, 51);
            this.txtSLTreEm.Name = "txtSLTreEm";
            this.txtSLTreEm.Size = new System.Drawing.Size(116, 30);
            this.txtSLTreEm.TabIndex = 26;
            // 
            // txtSLSinhVien
            // 
            this.txtSLSinhVien.BackColor = System.Drawing.Color.MintCream;
            this.txtSLSinhVien.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtSLSinhVien.Font = new System.Drawing.Font("Times New Roman", 12F);
            this.txtSLSinhVien.Location = new System.Drawing.Point(483, 93);
            this.txtSLSinhVien.Name = "txtSLSinhVien";
            this.txtSLSinhVien.Size = new System.Drawing.Size(116, 30);
            this.txtSLSinhVien.TabIndex = 25;
            // 
            // txtSLNguoiGia
            // 
            this.txtSLNguoiGia.BackColor = System.Drawing.Color.MintCream;
            this.txtSLNguoiGia.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtSLNguoiGia.Font = new System.Drawing.Font("Times New Roman", 12F);
            this.txtSLNguoiGia.Location = new System.Drawing.Point(227, 93);
            this.txtSLNguoiGia.Name = "txtSLNguoiGia";
            this.txtSLNguoiGia.Size = new System.Drawing.Size(116, 30);
            this.txtSLNguoiGia.TabIndex = 24;
            // 
            // lblLoaiVe
            // 
            this.lblLoaiVe.AutoSize = true;
            this.lblLoaiVe.BackColor = System.Drawing.Color.MintCream;
            this.lblLoaiVe.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLoaiVe.Location = new System.Drawing.Point(20, 57);
            this.lblLoaiVe.Name = "lblLoaiVe";
            this.lblLoaiVe.Size = new System.Drawing.Size(76, 22);
            this.lblLoaiVe.TabIndex = 15;
            this.lblLoaiVe.Text = "Loại vé:";
            // 
            // txtGhe
            // 
            this.txtGhe.BackColor = System.Drawing.Color.MintCream;
            this.txtGhe.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtGhe.Font = new System.Drawing.Font("Times New Roman", 12F);
            this.txtGhe.Location = new System.Drawing.Point(24, 188);
            this.txtGhe.Name = "txtGhe";
            this.txtGhe.Size = new System.Drawing.Size(581, 23);
            this.txtGhe.TabIndex = 19;
            this.txtGhe.Text = "[THÔNG TIN GHẾ VÀ SỐ LƯỢNG]";
            // 
            // txtThoiGian
            // 
            this.txtThoiGian.BackColor = System.Drawing.Color.MintCream;
            this.txtThoiGian.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtThoiGian.Font = new System.Drawing.Font("Times New Roman", 12F);
            this.txtThoiGian.Location = new System.Drawing.Point(24, 147);
            this.txtThoiGian.Name = "txtThoiGian";
            this.txtThoiGian.Size = new System.Drawing.Size(581, 23);
            this.txtThoiGian.TabIndex = 18;
            this.txtThoiGian.Text = "[THỜI GIAN SUẤT CHIẾU]";
            // 
            // lblThanhToan
            // 
            this.lblThanhToan.AutoSize = true;
            this.lblThanhToan.BackColor = System.Drawing.Color.MintCream;
            this.lblThanhToan.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblThanhToan.Location = new System.Drawing.Point(137, 14);
            this.lblThanhToan.Name = "lblThanhToan";
            this.lblThanhToan.Size = new System.Drawing.Size(169, 25);
            this.lblThanhToan.TabIndex = 10;
            this.lblThanhToan.Text = "THANH TOÁN";
            // 
            // txtSLNguoiLon
            // 
            this.txtSLNguoiLon.BackColor = System.Drawing.Color.MintCream;
            this.txtSLNguoiLon.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtSLNguoiLon.Font = new System.Drawing.Font("Times New Roman", 12F);
            this.txtSLNguoiLon.Location = new System.Drawing.Point(227, 51);
            this.txtSLNguoiLon.Name = "txtSLNguoiLon";
            this.txtSLNguoiLon.Size = new System.Drawing.Size(116, 30);
            this.txtSLNguoiLon.TabIndex = 17;
            // 
            // lblChiTiet
            // 
            this.lblChiTiet.AutoSize = true;
            this.lblChiTiet.BackColor = System.Drawing.Color.MintCream;
            this.lblChiTiet.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblChiTiet.Location = new System.Drawing.Point(10, 14);
            this.lblChiTiet.Name = "lblChiTiet";
            this.lblChiTiet.Size = new System.Drawing.Size(116, 25);
            this.lblChiTiet.TabIndex = 10;
            this.lblChiTiet.Text = "CHI TIẾT";
            // 
            // btnHuy
            // 
            this.btnHuy.BackColor = System.Drawing.Color.Maroon;
            this.btnHuy.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnHuy.ForeColor = System.Drawing.Color.White;
            this.btnHuy.Location = new System.Drawing.Point(239, 147);
            this.btnHuy.Name = "btnHuy";
            this.btnHuy.Size = new System.Drawing.Size(160, 38);
            this.btnHuy.TabIndex = 14;
            this.btnHuy.Text = "HỦY";
            this.btnHuy.UseVisualStyleBackColor = false;
            // 
            // btnClose
            // 
            this.btnClose.BackColor = System.Drawing.Color.Maroon;
            this.btnClose.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold);
            this.btnClose.ForeColor = System.Drawing.Color.White;
            this.btnClose.Location = new System.Drawing.Point(1036, 12);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(57, 38);
            this.btnClose.TabIndex = 31;
            this.btnClose.Text = "x";
            this.btnClose.UseVisualStyleBackColor = false;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // pnlThanhToan
            // 
            this.pnlThanhToan.BackColor = System.Drawing.Color.MintCream;
            this.pnlThanhToan.Controls.Add(this.btnHuy);
            this.pnlThanhToan.Controls.Add(this.txtTongTien);
            this.pnlThanhToan.Controls.Add(this.btnThanhToan);
            this.pnlThanhToan.Controls.Add(this.lblTongTien);
            this.pnlThanhToan.Controls.Add(this.lblThanhToan);
            this.pnlThanhToan.Location = new System.Drawing.Point(653, 403);
            this.pnlThanhToan.Name = "pnlThanhToan";
            this.pnlThanhToan.Size = new System.Drawing.Size(440, 235);
            this.pnlThanhToan.TabIndex = 29;
            // 
            // txtTongTien
            // 
            this.txtTongTien.Font = new System.Drawing.Font("Times New Roman", 12F);
            this.txtTongTien.Location = new System.Drawing.Point(121, 85);
            this.txtTongTien.Name = "txtTongTien";
            this.txtTongTien.Size = new System.Drawing.Size(302, 30);
            this.txtTongTien.TabIndex = 13;
            // 
            // btnThanhToan
            // 
            this.btnThanhToan.BackColor = System.Drawing.Color.Maroon;
            this.btnThanhToan.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnThanhToan.ForeColor = System.Drawing.Color.White;
            this.btnThanhToan.Location = new System.Drawing.Point(45, 147);
            this.btnThanhToan.Name = "btnThanhToan";
            this.btnThanhToan.Size = new System.Drawing.Size(160, 38);
            this.btnThanhToan.TabIndex = 10;
            this.btnThanhToan.Text = "THANH TOÁN";
            this.btnThanhToan.UseVisualStyleBackColor = false;
            // 
            // btnQuayLai
            // 
            this.btnQuayLai.BackColor = System.Drawing.Color.Maroon;
            this.btnQuayLai.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnQuayLai.ForeColor = System.Drawing.Color.White;
            this.btnQuayLai.Location = new System.Drawing.Point(13, 12);
            this.btnQuayLai.Name = "btnQuayLai";
            this.btnQuayLai.Size = new System.Drawing.Size(57, 38);
            this.btnQuayLai.TabIndex = 26;
            this.btnQuayLai.Text = "<";
            this.btnQuayLai.UseVisualStyleBackColor = false;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.MintCream;
            this.panel2.Controls.Add(this.lblLCP);
            this.panel2.Location = new System.Drawing.Point(303, 61);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(790, 50);
            this.panel2.TabIndex = 27;
            // 
            // lblLCP
            // 
            this.lblLCP.AutoSize = true;
            this.lblLCP.Font = new System.Drawing.Font("Times New Roman", 20.25F, System.Drawing.FontStyle.Bold);
            this.lblLCP.Location = new System.Drawing.Point(305, 6);
            this.lblLCP.Name = "lblLCP";
            this.lblLCP.Size = new System.Drawing.Size(198, 38);
            this.lblLCP.TabIndex = 0;
            this.lblLCP.Text = "MÀN HÌNH";
            // 
            // pnlChiTiet
            // 
            this.pnlChiTiet.BackColor = System.Drawing.Color.MintCream;
            this.pnlChiTiet.Controls.Add(this.checkBox4);
            this.pnlChiTiet.Controls.Add(this.checkBox3);
            this.pnlChiTiet.Controls.Add(this.checkBox2);
            this.pnlChiTiet.Controls.Add(this.checkBox1);
            this.pnlChiTiet.Controls.Add(this.txtSLTreEm);
            this.pnlChiTiet.Controls.Add(this.txtSLSinhVien);
            this.pnlChiTiet.Controls.Add(this.txtSLNguoiGia);
            this.pnlChiTiet.Controls.Add(this.txtSLNguoiLon);
            this.pnlChiTiet.Controls.Add(this.lblLoaiVe);
            this.pnlChiTiet.Controls.Add(this.txtGhe);
            this.pnlChiTiet.Controls.Add(this.txtThoiGian);
            this.pnlChiTiet.Controls.Add(this.lblChiTiet);
            this.pnlChiTiet.Location = new System.Drawing.Point(12, 403);
            this.pnlChiTiet.Name = "pnlChiTiet";
            this.pnlChiTiet.Size = new System.Drawing.Size(625, 235);
            this.pnlChiTiet.TabIndex = 28;
            // 
            // frmSeat
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Maroon;
            this.ClientSize = new System.Drawing.Size(1105, 650);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.flpSeat);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.pnlThanhToan);
            this.Controls.Add(this.btnQuayLai);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.pnlChiTiet);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "frmSeat";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "frmSeat";
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.pnlThanhToan.ResumeLayout(false);
            this.pnlThanhToan.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.pnlChiTiet.ResumeLayout(false);
            this.pnlChiTiet.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label lblTongTien;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.TextBox txtPhongChieu;
        private System.Windows.Forms.Label lblPhongChieu;
        private System.Windows.Forms.Label lblTrangThaiGhe;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnGheDangChon;
        private System.Windows.Forms.Button btnGheDaMua;
        private System.Windows.Forms.FlowLayoutPanel flpSeat;
        private System.Windows.Forms.CheckBox checkBox4;
        private System.Windows.Forms.CheckBox checkBox3;
        private System.Windows.Forms.CheckBox checkBox2;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.TextBox txtSLTreEm;
        private System.Windows.Forms.TextBox txtSLSinhVien;
        private System.Windows.Forms.TextBox txtSLNguoiGia;
        private System.Windows.Forms.Label lblLoaiVe;
        private System.Windows.Forms.TextBox txtGhe;
        private System.Windows.Forms.TextBox txtThoiGian;
        private System.Windows.Forms.Label lblThanhToan;
        private System.Windows.Forms.TextBox txtSLNguoiLon;
        private System.Windows.Forms.Label lblChiTiet;
        private System.Windows.Forms.Button btnHuy;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.Panel pnlThanhToan;
        private System.Windows.Forms.TextBox txtTongTien;
        private System.Windows.Forms.Button btnThanhToan;
        private System.Windows.Forms.Button btnQuayLai;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label lblLCP;
        private System.Windows.Forms.Panel pnlChiTiet;
    }
}