﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DTO
{
    public class DTONhanVien
    {
        private string maNV;
        private string hoTen;
        private DateTime ngaySinh;
	    private string diaChi;
	    private int sDT;
        private string gioiTinh;
        private float soGioLam;
        private decimal mucLuong;

        public string MaNV { get => maNV; set => maNV = value; }
        public string HoTen { get => hoTen; set => hoTen = value; }
        public DateTime NgaySinh { get => ngaySinh; set => ngaySinh = value; }
        public string DiaChi { get => diaChi; set => diaChi = value; }
        public int SDT { get => sDT; set => sDT = value; }
        public string GioiTinh { get => gioiTinh; set => gioiTinh = value; }
        public float SoGioLam { get => soGioLam; set => soGioLam = value; }
        public decimal MucLuong { get => mucLuong; set => mucLuong = value; }
    }
}
