﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.TaskbarClock;

namespace DTO
{
    public class DTOPhongChieu
    {
        private string maSC;
        private TimeSpan thoiGianBatDau;
        private TimeSpan thoiGianKetThuc;

        public string MaSC { get => maSC; set => maSC = value; }
        public TimeSpan ThoiGianBatDau { get => thoiGianBatDau; set => thoiGianBatDau = value; }
        public TimeSpan ThoiGianKetThuc { get => thoiGianKetThuc; set => thoiGianKetThuc = value; }
    }
}
