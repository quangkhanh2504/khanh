﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DTO
{
    public class DTOPhim
    {
        private string maPhim;
        private string tenPhim;
        private string theLoai;
        private string daoDien;
        private string nhaSX;
        private DateTime ngayCongChieu;
        private string gioiHanDoTuoi;

        public string MaPhim { get => maPhim; set => maPhim = value; }
        public string TenPhim { get => tenPhim; set => tenPhim = value; }
        public string TheLoai { get => theLoai; set => theLoai = value; }
        public string DaoDien { get => daoDien; set => daoDien = value; }
        public string NhaSX { get => nhaSX; set => nhaSX = value; }
        public DateTime NgayCongChieu { get => ngayCongChieu; set => ngayCongChieu = value; }
        public string GioiHanDoTuoi { get => gioiHanDoTuoi; set => gioiHanDoTuoi = value; }
    }
}
